import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import View.VentanaCaso;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }

            JFrame marcoPrincipal = new JFrame("ACTUAL LEGAL - Gestión de Casos");
            marcoPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            marcoPrincipal.setSize(1200, 750);
            marcoPrincipal.setLocationRelativeTo(null);

            VentanaCaso panelCaso = new VentanaCaso();
            marcoPrincipal.setContentPane(panelCaso);

            marcoPrincipal.setVisible(true);
        });
    }
}