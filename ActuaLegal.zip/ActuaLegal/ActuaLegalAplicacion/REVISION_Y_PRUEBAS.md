# Revisión técnica de Actua Legal

## Cambios realizados
- `CasoDAO`: se corrigieron los 12 marcadores SQL de `INSERT`.
- La tabla `caso` ahora incluye `cliente_representado`; si existe un esquema antiguo, la columna se añade sin borrar registros.
- `UPDATE` ahora persiste `cliente_representado`.
- La interfaz diferencia error de clave única de otros errores SQL.
- El botón Consultar abre la página oficial de la Rama Judicial. **No autocompleta campos**: el endpoint de API incorporado en el proyecto no está verificado y la Rama Judicial restringe las consultas automatizadas. La integración automática está pendiente de confirmar un mecanismo autorizado.

## Pruebas recomendadas
1. Hacer una copia de seguridad de cualquier `Basededatos.db` existente antes de ejecutar la nueva versión.
2. Compilar con Java 17+ y agregar al classpath el controlador `sqlite-jdbc` que corresponda a su entorno (el ZIP original no incluye el JAR).
3. Crear un caso nuevo con todos los campos y verificar que aparece en el listado.
4. Intentar registrar de nuevo el mismo radicado y verificar el mensaje de duplicado.
5. Editar la parte representada y comprobar que se conserva al reabrir.
6. Pulsar Consultar con un radicado de 23 dígitos; debe abrirse el sitio web oficial para consulta manual.

La base SQLite utiliza una ruta relativa al directorio desde el cual se ejecuta Java. Por tanto, ejecute Java desde el directorio del proyecto que contenga `Basededatos.db`, y tenga en cuenta que las variantes del ZIP contienen carpetas de proyecto distintas. No se ha incluido ni reemplazado ninguna base de datos en este paquete.
