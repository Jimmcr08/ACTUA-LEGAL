package View;

import model.ConsultaProcesosService;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

/**
 * Muestra el estado oficial del proceso TRAIDO DESDE LA RAMA JUDICIAL
 * dentro de esta misma ventana (ya no redirige al navegador).
 * El radicado llega ya validado desde VentanaCaso.
 */
public class ConsultaRamaJudicialDialog extends JDialog {

    private final Color COLOR_NEGRO = new Color(20, 20, 20);
    private final Color COLOR_DORADO = new Color(197, 160, 89);
    private final Color COLOR_FONDO = new Color(242, 244, 247);

    private final String radicado;
    private final ConsultaProcesosService service = new ConsultaProcesosService();

    private JTextArea txtResultado;
    private JButton btnConsultar;

    public ConsultaRamaJudicialDialog(JFrame parent, String radicado) {
        super(parent, "Consulta Procesos - Rama Judicial", true);
        this.radicado = radicado;
        setSize(720, 460);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        // Header Corporativo
        JPanel panelHeader = new JPanel(new BorderLayout());
        panelHeader.setBackground(COLOR_NEGRO);
        panelHeader.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));

        JLabel lblTitulo = new JLabel("CONSULTA NACIONAL UNIFICADA (CPNU)");
        lblTitulo.setFont(new Font("Serif", Font.BOLD, 15));
        lblTitulo.setForeground(COLOR_DORADO);
        panelHeader.add(lblTitulo, BorderLayout.WEST);

        JLabel lblRadicado = new JLabel("Radicado: " + radicado);
        lblRadicado.setFont(new Font("Monospaced", Font.BOLD, 12));
        lblRadicado.setForeground(Color.WHITE);
        panelHeader.add(lblRadicado, BorderLayout.EAST);

        // Resultado DENTRO de la aplicacion
        txtResultado = new JTextArea();
        txtResultado.setEditable(false);
        txtResultado.setFont(new Font("SansSerif", Font.PLAIN, 13));
        txtResultado.setLineWrap(true);
        txtResultado.setWrapStyleWord(true);
        txtResultado.setBackground(COLOR_FONDO);
        txtResultado.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));

        JScrollPane scroll = new JScrollPane(txtResultado);
        scroll.setBorder(BorderFactory.createEmptyBorder(16, 20, 8, 20));

        // Botonera
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 14));
        panelBotones.setBackground(COLOR_FONDO);

        btnConsultar = new JButton("VOLVER A CONSULTAR");
        estilizar(btnConsultar, COLOR_NEGRO, COLOR_DORADO);
        btnConsultar.addActionListener(e -> consultar());

        JButton btnCerrar = new JButton("CERRAR");
        estilizar(btnCerrar, new Color(225, 228, 233), COLOR_NEGRO);
        btnCerrar.addActionListener(e -> dispose());

        panelBotones.add(btnCerrar);
        panelBotones.add(btnConsultar);

        add(panelHeader, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        // Al abrir, consulta de una vez (el radicado ya viene validado por VentanaCaso)
        consultar();
    }

    private void estilizar(JButton b, Color fondo, Color texto) {
        b.setFont(new Font("SansSerif", Font.BOLD, 12));
        b.setBackground(fondo);
        b.setForeground(texto);
        b.setContentAreaFilled(true);
        b.setOpaque(true);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(200, 38));
    }

    /** Consulta la API en un hilo aparte para no congelar la ventana. */
    private void consultar() {
        btnConsultar.setEnabled(false);
        txtResultado.setText("Consultando el proceso en la Rama Judicial...\n\n"
                + "El portal publico puede tardar entre 5 y 30 segundos.\n"
                + "No cierre esta ventana.");

        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws Exception {
                return service.consultarProcesoPorRadicado(radicado);
            }

            @Override
            protected void done() {
                btnConsultar.setEnabled(true);
                try {
                    String json = get();
                    String idProceso = service.extraerCampoJson(json, "idProceso");
                    String despacho  = service.extraerCampoJson(json, "despacho");
                    String inicio    = service.extraerCampoJson(json, "fechaProceso");
                    String ultima    = service.extraerCampoJson(json, "fechaUltimaActuacion");
                    String sujetos   = service.extraerCampoJson(json, "sujetosProcesales");

                    if (idProceso == null && despacho == null) {
                        txtResultado.setText("El radicado " + radicado + " NO aparecio en la "
                                + "consulta nacional.\n\nVerifica los 23 digitos del numero "
                                + "o intenta de nuevo en unos minutos (los despachos replican"
                                + " la informacion de forma periodica).");
                        return;
                    }

                    StringBuilder sb = new StringBuilder();
                    sb.append("✔ PROCESO ENCONTRADO EN LA RAMA JUDICIAL\n\n");
                    sb.append("ID proceso (CPNU).....: ").append(ver(idProceso)).append("\n");
                    sb.append("Despacho..............: ").append(ver(despacho)).append("\n");
                    sb.append("Fecha de radicacion...: ").append(ver(inicio)).append("\n");
                    sb.append("Ultima actuacion......: ").append(ver(ultima)).append("\n\n");
                    sb.append("SUJETOS PROCESALES\n").append(ver(sujetos)).append("\n\n");
                    sb.append("-----------------------------------------------------------------\n");
                    sb.append("Informacion publica de la Consulta de Procesos Nacional Unificada");
                    txtResultado.setText(sb.toString());
                    txtResultado.setCaretPosition(0);

                } catch (Exception ex) {
                    Throwable causa = ex.getCause() != null ? ex.getCause() : ex;
                    String m = causa.getMessage() == null ? causa.toString() : causa.getMessage();
                    txtResultado.setText("✖ NO SE PUDO COMPLETAR LA CONSULTA\n\n" + m
                            + "\n\nEl portal de la Rama Judicial puede estar lento o en mantenimiento."
                            + "\nPulsa 'Volver a consultar' en unos momentos.");
                }
            }
        }.execute();
    }

    private String ver(String v) {
        return (v == null || v.trim().isEmpty()) ? "-" : v.trim();
    }
}
