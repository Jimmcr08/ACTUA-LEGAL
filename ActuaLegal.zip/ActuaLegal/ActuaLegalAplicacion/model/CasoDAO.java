package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CasoDAO {

    private final String url = "jdbc:sqlite:Basededatos.db";

    public CasoDAO() {
        crearTablaSiNoExiste();
    }

    private Connection conectar() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.err.println("Driver JDBC de SQLite no encontrado en el classpath.");
        }
        return DriverManager.getConnection(url);
    }

    private void crearTablaSiNoExiste() {
        String sql = "CREATE TABLE IF NOT EXISTS caso ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "clase TEXT,"
                + "apoderado TEXT,"
                + "demandante TEXT,"
                + "demandado TEXT,"
                + "cliente_representado TEXT,"
                + "cuantia TEXT,"
                + "radicado TEXT UNIQUE,"
                + "despacho TEXT,"
                + "etapa TEXT,"
                + "url_drive TEXT,"
                + "actuaciones_seguimiento TEXT,"
                + "actuaciones_realizar TEXT"
                + ");";

        try (Connection conn = conectar();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.err.println("Error al crear la tabla en SQLite: " + e.getMessage());
        }
    }

    public boolean guardarCaso(Caso caso) {
        String sql = "INSERT INTO caso (clase, apoderado, demandante, demandado, cliente_representado, cuantia, radicado, despacho, etapa, url_drive, actuaciones_seguimiento, actuaciones_realizar) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, caso.getClase());
            pstmt.setString(2, caso.getApoderadoJudicial());
            pstmt.setString(3, caso.getDemandante());
            pstmt.setString(4, caso.getDemandado());
            pstmt.setString(5, caso.getClienteRepresentado());
            pstmt.setString(6, caso.getCuantia());
            pstmt.setString(7, caso.getRadicado());
            pstmt.setString(8, caso.getDespachoJudicial());
            pstmt.setString(9, caso.getEtapaProcesal());
            pstmt.setString(10, caso.getUrlDrive());
            pstmt.setString(11, caso.getActuacionesSeguimiento());
            pstmt.setString(12, caso.getActuacionesARealizar());

            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al guardar en SQLite: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarCaso(Caso caso) {
        String sql = "UPDATE caso SET clase=?, apoderado=?, demandante=?, demandado=?, cliente_representado=?, cuantia=?, radicado=?, despacho=?, etapa=?, url_drive=?, actuaciones_seguimiento=?, actuaciones_realizar=? WHERE id=?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, caso.getClase());
            pstmt.setString(2, caso.getApoderadoJudicial());
            pstmt.setString(3, caso.getDemandante());
            pstmt.setString(4, caso.getDemandado());
            pstmt.setString(5, caso.getClienteRepresentado());
            pstmt.setString(6, caso.getCuantia());
            pstmt.setString(7, caso.getRadicado());
            pstmt.setString(8, caso.getDespachoJudicial());
            pstmt.setString(9, caso.getEtapaProcesal());
            pstmt.setString(10, caso.getUrlDrive());
            pstmt.setString(11, caso.getActuacionesSeguimiento());
            pstmt.setString(12, caso.getActuacionesARealizar());
            pstmt.setInt(13, caso.getId());

            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al actualizar caso: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarCaso(int id) {
        String sql = "DELETE FROM caso WHERE id = ?";
        try (Connection conn = conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al eliminar caso: " + e.getMessage());
            return false;
        }
    }

    public List<Caso> listarCasos() {
        List<Caso> lista = new ArrayList<>();
        String sql = "SELECT * FROM caso";
        try (Connection conn = conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Caso c = new Caso();
                c.setId(rs.getInt("id"));
                c.setClase(rs.getString("clase"));
                c.setApoderadoJudicial(rs.getString("apoderado"));
                c.setDemandante(rs.getString("demandante"));
                c.setDemandado(rs.getString("demandado"));
                c.setClienteRepresentado(rs.getString("cliente_representado"));
                c.setCuantia(rs.getString("cuantia"));
                c.setRadicado(rs.getString("radicado"));
                c.setDespachoJudicial(rs.getString("despacho"));
                c.setEtapaProcesal(rs.getString("etapa"));
                c.setUrlDrive(rs.getString("url_drive"));
                c.setActuacionesSeguimiento(rs.getString("actuaciones_seguimiento"));
                c.setActuacionesARealizar(rs.getString("actuaciones_realizar"));
                lista.add(c);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar casos: " + e.getMessage());
        }
        return lista;
    }
}