package model;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ConsultaProcesosService {
    private final HttpClient httpClient;
    private static final String API_URL = "https://consultaprocesos.ramajudicial.gov.co:448/api/v2";

    public ConsultaProcesosService() {
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    //Limpia y valida los 23 digitos del numero de radicacion
    public String normalizarRadicacion(String radicadoRaw){
        if(radicadoRaw == null) return "";
        //Elimina todos los caracteres que no sean digitos
        String limpio = radicadoRaw.replaceAll("[^0-9]", "");
        return limpio;
    }

    //Consulta el numero de radicacion en la API de la pagina del gobierno
    public String consultarProcesoPorRadicado(String radicado) throws Exception {
        String radicadolimpio = normalizarRadicacion(radicado);

        if (radicadolimpio.length()!= 23){
            throw new IllegalArgumentException("El numero de radicacion debe tener 23 digitos");
        }

        // Endpoint real verificado contra la CPNU (antes faltaba el path y la N era mayuscula)
        String urlFinal = API_URL + "/Procesos/Consulta/NumeroRadicacion?numero="
                + radicadolimpio + "&SoloActivos=false&pagina=1";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(urlFinal))
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                .header("Accept", "application/json")
                .GET()
                .timeout(Duration.ofSeconds(20))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() == 200){
            return response.body();
        }else if (response.statusCode() == 404){
            throw new RuntimeException("No se encontro el numero de radicacion");
        }else{
            throw new RuntimeException("Error en servidor judicial (codigo:" + response.statusCode() + ")");
        }
    }

    public String extraerCampoJson(String json, String clave){
        try{
            // valores de texto entre comillas:  "clave": "valor"
            Pattern pattern = Pattern.compile("\"" + clave + "\"\\s*:\\s*\"(.*?)\"");
            Matcher matcher = pattern.matcher(json);
            if (matcher.find()){
                return matcher.group(1);
            }
            // valores SIN comillas (numero, true/false/null):  "idProceso":121636283
            Pattern numerico = Pattern.compile("\"" + clave + "\"\\s*:\\s*(-?[0-9]+(?:\\.[0-9]+)?|true|false|null)");
            Matcher mNum = numerico.matcher(json);
            if (mNum.find()){
                return mNum.group(1);
            }
        }catch (Exception e){
            System.err.println("Error al extraer el campo " + clave + ": " + e.getMessage());
        }
        return null;
    }
}
